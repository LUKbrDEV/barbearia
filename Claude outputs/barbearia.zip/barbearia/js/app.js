// App do cliente: início, agendamento, meus horários, informações, PWA.
{
  const A = window.Agenda, S = window.Store;
  const $ = s => document.querySelector(s);
  const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const money = n => Number(n || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  const DIAS = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  const ls = { get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
               set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} } };
  const fmtData = (s, longo) => A.parseYMD(s).toLocaleDateString("pt-BR", longo ? { weekday: "long", day: "numeric", month: "long" } : { weekday: "short", day: "2-digit", month: "2-digit" });
  const durTxt = m => m >= 60 ? Math.floor(m / 60) + "h" + (m % 60 ? String(m % 60).padStart(2, "0") : "") : m + " min";
  const wa = (num, txt) => "https://wa.me/" + String(num || "").replace(/\D/g, "") + (txt ? "?text=" + encodeURIComponent(txt) : "");

  let cfg = window.DEFAULT_CONFIG;
  let toastT;
  function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("on"); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("on"), 2800); }
  function modal(html) { $("#modalBox").innerHTML = html; $("#modal").hidden = false; return $("#modalBox"); }
  function fecharModal() { $("#modal").hidden = true; $("#modalBox").innerHTML = ""; }
  $("#modal").addEventListener("click", e => { if (e.target.id === "modal" || e.target.closest("[data-fechar]")) fecharModal(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape" && !$("#modal").hidden) fecharModal(); });

  function ics(ag) {
    const d = ag.data.replace(/-/g, ""), h = ag.hora.replace(":", "") + "00", f = A.toHM(A.toMin(ag.hora) + ag.dur).replace(":", "") + "00";
    const txt = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Barbearia//PT", "BEGIN:VEVENT", "UID:" + ag.id,
      "DTSTART:" + d + "T" + h, "DTEND:" + d + "T" + f, "SUMMARY:" + ag.servico + " - " + cfg.nome,
      "LOCATION:" + (cfg.endereco || ""), "BEGIN:VALARM", "TRIGGER:-PT1H", "ACTION:DISPLAY", "DESCRIPTION:Lembrete", "END:VALARM",
      "END:VEVENT", "END:VCALENDAR"].join("\r\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([txt], { type: "text/calendar" })); a.download = "agendamento.ics";
    document.body.appendChild(a); a.click(); a.remove();
  }

  // ---------- INÍCIO ----------
  function abertoAgora() {
    const n = new Date(), h = cfg.horarios[n.getDay()], m = n.getHours() * 60 + n.getMinutes();
    if (!h || !h.aberto) return false;
    if (m < A.toMin(h.abre) || m >= A.toMin(h.fecha)) return false;
    if (h.almocoIni && h.almocoFim && m >= A.toMin(h.almocoIni) && m < A.toMin(h.almocoFim)) return false;
    return true;
  }
  async function renderInicio() {
    document.title = cfg.nome;
    $("#marcaNome").textContent = cfg.nome; $("#heroNome").textContent = cfg.nome; $("#heroSlogan").textContent = cfg.slogan || "";
    const ab = abertoAgora(), st = $("#statusAberto");
    st.textContent = ab ? "Aberto agora" : "Fechado agora"; st.classList.toggle("on", ab);
    $("#listaServicos").innerHTML = cfg.servicos.map(s => `<li><b>${esc(s.nome)}</b><span class="preco">${money(s.preco)}</span><small>${esc(durTxt(s.dur))}${s.desc ? " · " + esc(s.desc) : ""}</small></li>`).join("");
    const hoje = new Date().getDay();
    $("#listaHorarios").innerHTML = [1, 2, 3, 4, 5, 6, 0].map(i => { const h = cfg.horarios[i];
      return `<li class="${i === hoje ? "hoje" : ""}"><span>${DIAS[i]}</span><span>${h && h.aberto ? esc(h.abre) + " – " + esc(h.fecha) + (h.almocoIni ? " <small>(pausa " + esc(h.almocoIni) + ")</small>" : "") : "Fechado"}</span></li>`; }).join("");
    $("#contatoInicio").innerHTML = contatos();
    // próximo horário livre
    try {
      const menor = Math.min(...cfg.servicos.map(s => s.dur)), hojeS = A.ymd(new Date()), fim = A.addDays(hojeS, 7);
      const busy = await S.ocupados(hojeS, fim);
      for (let i = 0; i <= 7; i++) {
        const d = A.addDays(hojeS, i), r = A.slotsDoDia(cfg, d, menor, busy).slots.find(x => x.livre);
        if (r) { $("#proximoLivre").innerHTML = `Próximo horário livre: <b>${i === 0 ? "hoje" : i === 1 ? "amanhã" : esc(fmtData(d))} às ${r.hora}</b>`; break; }
      }
    } catch { $("#proximoLivre").textContent = ""; }
  }
  function contatos() {
    let h = "";
    if (cfg.whatsapp) h += `<a class="btn btn-ok" href="${esc(wa(cfg.whatsapp, "Olá! Vim pelo app da " + cfg.nome + "."))}" target="_blank" rel="noopener">WhatsApp</a>`;
    if (cfg.instagram) h += `<a class="btn btn-sec" href="https://instagram.com/${esc(cfg.instagram.replace("@", ""))}" target="_blank" rel="noopener">Instagram</a>`;
    const maps = cfg.mapsUrl || (cfg.endereco ? "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(cfg.endereco) : "");
    if (maps) h += `<a class="btn btn-sec" href="${esc(maps)}" target="_blank" rel="noopener">Como chegar</a>`;
    return h;
  }

  // ---------- AGENDAR ----------
  const st = { serv: null, dia: null, hora: null, busy: [] };
  async function renderAgendar() {
    $("#erroAgendar").textContent = "";
    $("#campoTel").hidden = !cfg.pedirTelefone;
    $("#inNome").value = $("#inNome").value || ls.get("bb_nome", "");
    $("#inTel").value = $("#inTel").value || ls.get("bb_tel", "");
    if (st.serv && !cfg.servicos.some(s => s.id === st.serv)) st.serv = null;
    $("#escServico").innerHTML = cfg.servicos.map(s => `<label class="op"><input type="radio" name="serv" value="${esc(s.id)}" ${st.serv === s.id ? "checked" : ""}><span><b>${esc(s.nome)}</b><small>${money(s.preco)} · ${esc(durTxt(s.dur))}</small></span></label>`).join("");
    const hoje = A.ymd(new Date()), fim = A.addDays(hoje, cfg.diasAgenda - 1);
    try { st.busy = await S.ocupados(hoje, fim); } catch (e) { $("#erroAgendar").textContent = "Sem conexão. Tente novamente."; st.busy = []; }
    let dias = "";
    for (let i = 0; i < cfg.diasAgenda; i++) {
      const d = A.addDays(hoje, i), dt = A.parseYMD(d), h = cfg.horarios[dt.getDay()];
      const fechado = !h || !h.aberto || st.busy.some(b => b.data === d && !b.ini);
      dias += `<label class="op ${fechado ? "fechado" : ""}"><input type="radio" name="dia" value="${d}" ${st.dia === d ? "checked" : ""}><span><small>${i === 0 ? "hoje" : i === 1 ? "amanhã" : dt.toLocaleDateString("pt-BR", { weekday: "short" }).replace(".", "")}</small><b>${dt.getDate()}</b><small>${dt.toLocaleDateString("pt-BR", { month: "short" }).replace(".", "")}</small></span></label>`;
    }
    $("#escDia").innerHTML = dias;
    if (!st.dia) { // pré-seleciona o primeiro dia aberto
      const p = $("#escDia .op:not(.fechado) input"); if (p) { p.checked = true; st.dia = p.value; }
    }
    renderHoras(); atualizar();
  }
  function renderHoras() {
    const box = $("#escHora");
    if (!st.serv || !st.dia) { box.innerHTML = `<p class="vazio">Escolha o serviço e o dia.</p>`; return; }
    const s = cfg.servicos.find(x => x.id === st.serv);
    const r = A.slotsDoDia(cfg, st.dia, s.dur, st.busy);
    const livres = r.slots.filter(x => x.livre);
    if (r.fechado) { box.innerHTML = `<p class="vazio">Fechado neste dia. Escolha outro.</p>`; st.hora = null; return; }
    if (!livres.length) { box.innerHTML = `<p class="vazio">Sem horários livres neste dia. Tente o próximo.</p>`; st.hora = null; return; }
    if (st.hora && !livres.some(x => x.hora === st.hora)) st.hora = null;
    box.innerHTML = r.slots.map(x => `<label class="op ${x.livre ? "" : "ocupado"}"><input type="radio" name="hora" value="${x.hora}" ${x.livre ? "" : "disabled"} ${st.hora === x.hora ? "checked" : ""}><span>${x.hora}</span></label>`).join("");
  }
  function atualizar() {
    const s = cfg.servicos.find(x => x.id === st.serv), nome = $("#inNome").value.trim();
    $("#fsDia").classList.toggle("travado", !s);
    $("#fsHora").classList.toggle("travado", !s || !st.dia);
    $("#fsNome").classList.toggle("travado", !st.hora);
    let r = "Escolha um serviço";
    if (s) r = `<b>${esc(s.nome)}</b> · ${money(s.preco)}<br>` + (st.dia ? esc(fmtData(st.dia)) + (st.hora ? " às " + st.hora : " · escolha o horário") : "escolha o dia");
    $("#resumo").innerHTML = r;
    $("#btnConfirmar").disabled = !(s && st.dia && st.hora && nome.length >= 2);
  }
  $("#formAgendar").addEventListener("change", e => {
    const t = e.target;
    if (t.name === "serv") { st.serv = t.value; renderHoras(); }
    if (t.name === "dia") { st.dia = t.value; st.hora = null; renderHoras(); }
    if (t.name === "hora") { st.hora = t.value; setTimeout(() => $("#inNome").focus({ preventScroll: false }), 50); }
    atualizar();
  });
  $("#inNome").addEventListener("input", atualizar);
  $("#formAgendar").addEventListener("submit", async e => {
    e.preventDefault();
    const nome = $("#inNome").value.trim(), tel = $("#inTel").value.trim();
    if (nome.length < 2) { $("#erroAgendar").textContent = "Digite seu nome."; return; }
    const btn = $("#btnConfirmar"); btn.disabled = true; btn.textContent = "Agendando…";
    try {
      const s = cfg.servicos.find(x => x.id === st.serv);
      const r = await S.agendar({ servico_id: st.serv, nome, telefone: tel, data: st.dia, hora: st.hora });
      const ag = { id: r.id, token: r.token, data: st.dia, hora: st.hora, dur: s.dur, servico: s.nome, preco: s.preco, nome };
      ls.set("bb_meus", ls.get("bb_meus", []).concat(ag)); ls.set("bb_nome", nome); if (tel) ls.set("bb_tel", tel);
      st.hora = null;
      sucesso(ag);
      renderAgendar();
    } catch (err) {
      $("#erroAgendar").textContent = err.message || "Não foi possível agendar.";
      try { st.busy = await S.ocupados(st.dia, st.dia).then(b => st.busy.filter(x => x.data !== st.dia).concat(b)); } catch {}
      st.hora = null; renderHoras(); atualizar();
    } finally { btn.textContent = "Confirmar"; atualizar(); }
  });
  function msgWa(ag, tipo) {
    return (tipo === "cancel" ? "Olá! Cancelei meu horário: " : "Olá! Acabei de agendar pelo app: ") +
      `${ag.servico} em ${fmtData(ag.data)} às ${ag.hora}. Nome: ${ag.nome}`;
  }
  function sucesso(ag) {
    const b = modal(`<div class="ticket"><span class="tag agendado">Confirmado</span>
      <p class="quando">${esc(fmtData(ag.data, true))}<br>às ${esc(ag.hora)}</p>
      <p style="margin:0"><b>${esc(ag.servico)}</b> · ${money(ag.preco)} · ${esc(durTxt(ag.dur))}<br>${esc(ag.nome)}</p></div>
      <p style="color:var(--mut);margin-top:0">Seu horário fica salvo em <b>Meus</b>. Se não puder vir, cancele por lá.</p>
      <div style="display:grid;gap:8px">
        ${cfg.whatsapp ? `<a class="btn btn-ok" target="_blank" rel="noopener" href="${esc(wa(cfg.whatsapp, msgWa(ag)))}">Avisar no WhatsApp</a>` : ""}
        <button class="btn btn-sec" id="mIcs">Adicionar ao calendário</button>
        <button class="btn" data-fechar>Pronto</button></div>`);
    b.querySelector("#mIcs").onclick = () => ics(ag);
  }

  // ---------- MEUS ----------
  async function renderMeus() {
    const box = $("#listaMeus"); let meus = ls.get("bb_meus", []);
    if (!meus.length) { box.innerHTML = `<p class="vazio">Você ainda não tem horários.</p><p><a class="btn" href="#agendar">Agendar agora</a></p>`; return; }
    let sts = {};
    try { (await S.statusCliente(meus.map(m => m.id))).forEach(x => sts[x.id] = x.status); } catch {}
    const agora = A.ymd(new Date()) + " " + A.toHM(new Date().getHours() * 60 + new Date().getMinutes());
    meus = meus.map(m => Object.assign(m, { status: sts[m.id] || m.status || "agendado", passado: (m.data + " " + m.hora) < agora }))
      .sort((a, b) => a.passado !== b.passado ? (a.passado ? 1 : -1)
        : a.passado ? (b.data + b.hora).localeCompare(a.data + a.hora) : (a.data + a.hora).localeCompare(b.data + b.hora));
    const rot = { agendado: "Agendado", concluido: "Concluído", cancelado: "Cancelado", faltou: "Não compareceu" };
    box.innerHTML = meus.map(m => `<div class="ticket" data-id="${esc(m.id)}">
      <span class="tag ${esc(m.status)}">${m.passado && m.status === "agendado" ? "Passado" : esc(rot[m.status] || m.status)}</span>
      <p class="quando">${esc(fmtData(m.data, true))} · ${esc(m.hora)}</p>
      <p style="margin:0"><b>${esc(m.servico)}</b> · ${money(m.preco)}</p>
      <div class="acoes">${!m.passado && m.status === "agendado" ? `<button class="btn btn-mini btn-sec" data-a="ics">Calendário</button><button class="btn btn-mini" data-a="cancelar">Cancelar</button>` : `<button class="lnk" data-a="remover">Remover da lista</button><a class="lnk" href="#agendar">Agendar de novo</a>`}</div></div>`).join("");
    ls.set("bb_meus", meus.map(({ passado, ...m }) => m));
  }
  $("#listaMeus").addEventListener("click", e => {
    const b = e.target.closest("[data-a]"); if (!b) return;
    const id = b.closest("[data-id]").dataset.id, meus = ls.get("bb_meus", []), m = meus.find(x => x.id === id);
    if (b.dataset.a === "ics") ics(m);
    if (b.dataset.a === "remover") { ls.set("bb_meus", meus.filter(x => x.id !== id)); renderMeus(); }
    if (b.dataset.a === "cancelar") {
      const mb = modal(`<h2>Cancelar horário?</h2><p>${esc(m.servico)} em ${esc(fmtData(m.data, true))} às ${esc(m.hora)}.</p>
        <div style="display:grid;gap:8px"><button class="btn" id="mSim">Sim, cancelar</button><button class="btn btn-sec" data-fechar>Manter horário</button></div>`);
      mb.querySelector("#mSim").onclick = async () => {
        try { await S.cancelar(m.id, m.token); m.status = "cancelado"; ls.set("bb_meus", meus); toast("Horário cancelado.");
          if (cfg.whatsapp) { modal(`<h2>Cancelado</h2><p>Quer avisar a barbearia?</p><div style="display:grid;gap:8px"><a class="btn btn-ok" target="_blank" rel="noopener" href="${esc(wa(cfg.whatsapp, msgWa(m, "cancel")))}">Avisar no WhatsApp</a><button class="btn btn-sec" data-fechar>Fechar</button></div>`); }
          else fecharModal();
          renderMeus();
        } catch (err) { toast(err.message); fecharModal(); }
      };
    }
  });

  // ---------- INFO ----------
  function renderInfo() {
    const maps = cfg.mapsUrl || (cfg.endereco ? "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(cfg.endereco) : "");
    $("#infoConteudo").innerHTML = `<ul class="info-lista">
      ${cfg.endereco ? `<li><small>Endereço</small>${maps ? `<a href="${esc(maps)}" target="_blank" rel="noopener">${esc(cfg.endereco)}</a>` : esc(cfg.endereco)}</li>` : ""}
      ${cfg.whatsapp ? `<li><small>WhatsApp</small><a href="${esc(wa(cfg.whatsapp))}" target="_blank" rel="noopener">+${esc(cfg.whatsapp)}</a></li>` : ""}
      ${cfg.instagram ? `<li><small>Instagram</small><a href="https://instagram.com/${esc(cfg.instagram.replace("@", ""))}" target="_blank" rel="noopener">@${esc(cfg.instagram.replace("@", ""))}</a></li>` : ""}
      <li><small>Agendamento</small>Até ${esc(cfg.diasAgenda)} dias de antecedência, com no mínimo ${esc(cfg.antecedenciaMin)} min antes do horário.</li></ul>
      <div class="contato" style="margin-bottom:24px">${contatos()}</div>`;
  }

  // ---------- ROTEADOR ----------
  const VIEWS = ["inicio", "agendar", "meus", "info", "painel"];
  function rota() {
    const v = VIEWS.includes(location.hash.slice(1)) ? location.hash.slice(1) : "inicio";
    VIEWS.forEach(x => { $("#v-" + x).hidden = x !== v; });
    document.querySelectorAll(".tabbar a").forEach(a => a.classList.toggle("ativo", a.dataset.v === v));
    document.body.classList.toggle("admin", v === "painel");
    window.scrollTo(0, 0);
    if (v === "inicio") renderInicio();
    if (v === "agendar") renderAgendar();
    if (v === "meus") renderMeus();
    if (v === "info") renderInfo();
    if (v === "painel" && window.Painel) window.Painel.render();
  }
  addEventListener("hashchange", rota);

  async function carregarCfg() {
    try { cfg = await S.getConfig(); }
    catch { cfg = Object.assign({}, window.DEFAULT_CONFIG, ls.get("bb_cfg_cache", {})); toast("Sem conexão: mostrando dados salvos."); }
    window.App.cfg = cfg;
  }

  // ---------- PWA ----------
  let promptInst = null;
  addEventListener("beforeinstallprompt", e => { e.preventDefault(); promptInst = e; $("#btnInstalar").hidden = false; });
  $("#btnInstalar").addEventListener("click", async () => {
    if (!promptInst) return; promptInst.prompt(); await promptInst.userChoice; promptInst = null; $("#btnInstalar").hidden = true;
  });
  addEventListener("appinstalled", () => { $("#btnInstalar").hidden = true; toast("App instalado!"); });
  if ("serviceWorker" in navigator) { try { navigator.serviceWorker.register("sw.js").catch(() => {}); } catch {} }
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) { try { document.querySelector(".poste").pauseAnimations(); } catch {} }

  window.App = { cfg, esc, money, toast, modal, fecharModal, fmtData, durTxt, wa, DIAS,
    async recarregar() { await carregarCfg(); }, rota };
  carregarCfg().then(rota);
}
