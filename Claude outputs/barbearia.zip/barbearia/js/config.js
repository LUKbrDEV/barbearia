// ===== CONFIGURAÇÃO DO BACKEND =====
// Deixe SUPABASE_URL vazio para rodar em "modo demonstração" (dados salvos só neste aparelho).
// Para uso real (clientes e barbeiro em aparelhos diferentes), crie um projeto no Supabase,
// rode o arquivo supabase/schema.sql e preencha abaixo.
window.BARBER_BACKEND = {
  SUPABASE_URL: "",       // ex: "https://xxxx.supabase.co"
  SUPABASE_ANON_KEY: ""   // chave "anon public" do projeto
};

// Configuração inicial (usada no modo demonstração e como padrão do Supabase).
// Tudo isso pode ser editado depois no Painel do barbeiro.
window.DEFAULT_CONFIG = {
  nome: "Barbearia Navalha",
  slogan: "Corte, barba e conversa boa.",
  whatsapp: "5538999990000",
  endereco: "Rua Exemplo, 123 - Centro",
  instagram: "barbearianavalha",
  mapsUrl: "",
  pedirTelefone: false,
  intervalo: 30,          // minutos entre horários oferecidos
  antecedenciaMin: 60,    // minutos mínimos antes do horário para agendar
  diasAgenda: 21,         // quantos dias à frente o cliente pode agendar
  horarios: {             // 0=Dom ... 6=Sáb
    0: { aberto: false, abre: "09:00", fecha: "13:00", almocoIni: "", almocoFim: "" },
    1: { aberto: false, abre: "09:00", fecha: "19:00", almocoIni: "12:00", almocoFim: "13:00" },
    2: { aberto: true,  abre: "09:00", fecha: "19:00", almocoIni: "12:00", almocoFim: "13:00" },
    3: { aberto: true,  abre: "09:00", fecha: "19:00", almocoIni: "12:00", almocoFim: "13:00" },
    4: { aberto: true,  abre: "09:00", fecha: "19:00", almocoIni: "12:00", almocoFim: "13:00" },
    5: { aberto: true,  abre: "09:00", fecha: "20:00", almocoIni: "12:00", almocoFim: "13:00" },
    6: { aberto: true,  abre: "08:00", fecha: "17:00", almocoIni: "", almocoFim: "" }
  },
  servicos: [
    { id: "corte",   nome: "Corte",              preco: 40, dur: 30, desc: "Máquina e tesoura, com acabamento na navalha." },
    { id: "barba",   nome: "Barba",              preco: 30, dur: 30, desc: "Toalha quente, navalha e balm." },
    { id: "combo",   nome: "Corte + Barba",      preco: 65, dur: 60, desc: "O completo, com desconto." },
    { id: "degrade", nome: "Degradê navalhado",  preco: 50, dur: 45, desc: "Fade bem marcado e risco opcional." },
    { id: "sobr",    nome: "Sobrancelha",        preco: 15, dur: 15, desc: "Limpeza na navalha ou pinça." },
    { id: "pigm",    nome: "Pigmentação",        preco: 35, dur: 30, desc: "Disfarça falhas no cabelo ou barba." }
  ],
  pinHash: "" // vazio = PIN padrão 1234 (modo demonstração)
};
