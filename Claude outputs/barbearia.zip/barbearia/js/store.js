// Camada de dados: modo local (demonstração) ou Supabase (produção).
(function () {
  const { SUPABASE_URL, SUPABASE_ANON_KEY } = window.BARBER_BACKEND || {};
  const A = window.Agenda;
  const ls = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
  };
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));
  async function sha(t) {
    const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t));
    return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
  }
  const fimDe = a => A.toHM(A.toMin(a.hora) + a.dur);
  const ATIVOS = ["agendado", "concluido"];

  // ---------- MODO LOCAL ----------
  const Local = {
    modo: "local",
    async getConfig() { return Object.assign({}, window.DEFAULT_CONFIG, ls.get("bb_cfg", {})); },
    async saveConfig(cfg) { ls.set("bb_cfg", cfg); },
    async ocupados(de, ate) {
      const ags = ls.get("bb_ags", []).filter(a => ATIVOS.includes(a.status) && a.data >= de && a.data <= ate)
        .map(a => ({ data: a.data, ini: a.hora, fim: fimDe(a) }));
      const blq = ls.get("bb_blq", []).filter(b => b.data >= de && b.data <= ate).map(b => ({ data: b.data, ini: b.ini, fim: b.fim }));
      return ags.concat(blq);
    },
    async agendar({ servico_id, nome, telefone, data, hora }) {
      const cfg = await this.getConfig();
      const s = cfg.servicos.find(x => x.id === servico_id);
      if (!s) throw new Error("Serviço indisponível.");
      const r = A.slotsDoDia(cfg, data, s.dur, await this.ocupados(data, data));
      if (!r.slots.some(x => x.hora === hora && x.livre)) throw new Error("Esse horário acabou de ser ocupado. Escolha outro.");
      const ag = { id: uid(), token: uid(), data, hora, dur: s.dur, servico_id, servico_nome: s.nome, preco: s.preco,
        nome, telefone: telefone || "", status: "agendado", origem: "online", criado_em: new Date().toISOString() };
      ls.set("bb_ags", ls.get("bb_ags", []).concat(ag));
      return { id: ag.id, token: ag.token };
    },
    async statusCliente(ids) {
      return ls.get("bb_ags", []).filter(a => ids.includes(a.id)).map(a => ({ id: a.id, status: a.status }));
    },
    async cancelar(id, token) {
      const ags = ls.get("bb_ags", []); const a = ags.find(x => x.id === id && x.token === token);
      if (!a || a.status !== "agendado") throw new Error("Não foi possível cancelar.");
      a.status = "cancelado"; ls.set("bb_ags", ags);
    },
    // admin
    async login(_email, pin) {
      const cfg = await this.getConfig();
      const ok = cfg.pinHash ? (await sha(pin)) === cfg.pinHash : pin === "1234";
      if (!ok) throw new Error("PIN incorreto.");
      sessionStorage.setItem("bb_admin", "1");
    },
    logado() { try { return sessionStorage.getItem("bb_admin") === "1"; } catch { return false; } },
    sair() { try { sessionStorage.removeItem("bb_admin"); } catch {} },
    async listar(de, ate) {
      return ls.get("bb_ags", []).filter(a => a.data >= de && a.data <= ate)
        .sort((x, y) => (x.data + x.hora).localeCompare(y.data + y.hora));
    },
    async atualizar(id, patch) { const ags = ls.get("bb_ags", []); Object.assign(ags.find(a => a.id === id) || {}, patch); ls.set("bb_ags", ags); },
    async criar(ag) { ls.set("bb_ags", ls.get("bb_ags", []).concat(Object.assign({ id: uid(), token: uid(), criado_em: new Date().toISOString() }, ag))); },
    async bloqueios(de) { return ls.get("bb_blq", []).filter(b => b.data >= de).sort((a, b) => (a.data + (a.ini || "")).localeCompare(b.data + (b.ini || ""))); },
    async bloquear(b) { ls.set("bb_blq", ls.get("bb_blq", []).concat(Object.assign({ id: uid() }, b))); },
    async desbloquear(id) { ls.set("bb_blq", ls.get("bb_blq", []).filter(b => b.id !== id)); },
    async setPin(pin) { const cfg = await this.getConfig(); cfg.pinHash = await sha(pin); await this.saveConfig(cfg); },
    async exportar() { return { cfg: ls.get("bb_cfg", {}), ags: ls.get("bb_ags", []), blq: ls.get("bb_blq", []) }; },
    async importar(d) { if (d.cfg) ls.set("bb_cfg", d.cfg); if (d.ags) ls.set("bb_ags", d.ags); if (d.blq) ls.set("bb_blq", d.blq); }
  };

  // ---------- MODO SUPABASE ----------
  const sess = { get: () => ls.get("bb_sess", null), set: v => ls.set("bb_sess", v) };
  async function sb(path, opt = {}) {
    let s = sess.get();
    if (opt.auth && s && s.exp < Date.now() + 60000) s = await refresh(s);
    const headers = Object.assign({ apikey: SUPABASE_ANON_KEY, "Content-Type": "application/json",
      Authorization: "Bearer " + (opt.auth && s ? s.access : SUPABASE_ANON_KEY) }, opt.headers || {});
    const r = await fetch(SUPABASE_URL + path, { method: opt.method || "GET", headers, body: opt.body ? JSON.stringify(opt.body) : undefined });
    const txt = await r.text(); let j = null; try { j = txt ? JSON.parse(txt) : null; } catch {}
    if (!r.ok) {
      const msg = (j && (j.message || j.msg || j.error_description)) || "Erro de conexão.";
      throw new Error(/ocupado/i.test(msg) ? "Esse horário acabou de ser ocupado. Escolha outro." : msg);
    }
    return j;
  }
  async function refresh(s) {
    try {
      const j = await fetch(SUPABASE_URL + "/auth/v1/token?grant_type=refresh_token", { method: "POST",
        headers: { apikey: SUPABASE_ANON_KEY, "Content-Type": "application/json" }, body: JSON.stringify({ refresh_token: s.refresh }) }).then(r => r.json());
      if (!j.access_token) throw 0;
      const n = { access: j.access_token, refresh: j.refresh_token, exp: Date.now() + j.expires_in * 1000 }; sess.set(n); return n;
    } catch { sess.set(null); return null; }
  }
  const norm = a => Object.assign({}, a, { hora: String(a.hora).slice(0, 5), preco: Number(a.preco) });
  const Supa = {
    modo: "supabase",
    async getConfig() {
      const r = await sb("/rest/v1/config?id=eq.1&select=data");
      const c = Object.assign({}, window.DEFAULT_CONFIG, (r && r[0] && r[0].data) || {});
      try { ls.set("bb_cfg_cache", c); } catch {}
      return c;
    },
    async saveConfig(cfg) { const c = Object.assign({}, cfg); delete c.pinHash; await sb("/rest/v1/config?id=eq.1", { method: "PATCH", auth: true, body: { data: c } }); },
    async ocupados(de, ate) {
      const r = await sb("/rest/v1/rpc/horarios_ocupados", { method: "POST", body: { p_de: de, p_ate: ate } });
      return (r || []).map(x => ({ data: x.data, ini: x.ini ? x.ini.slice(0, 5) : "", fim: x.fim ? x.fim.slice(0, 5) : "" }));
    },
    async agendar({ servico_id, nome, telefone, data, hora }) {
      return await sb("/rest/v1/rpc/agendar", { method: "POST", body: { p_servico: servico_id, p_nome: nome, p_tel: telefone || "", p_data: data, p_hora: hora } });
    },
    async statusCliente(ids) {
      if (!ids.length) return [];
      return (await sb("/rest/v1/rpc/status_agendamentos", { method: "POST", body: { p_ids: ids } })) || [];
    },
    async cancelar(id, token) { await sb("/rest/v1/rpc/cancelar_agendamento", { method: "POST", body: { p_id: id, p_token: token } }); },
    async login(email, senha) {
      const j = await fetch(SUPABASE_URL + "/auth/v1/token?grant_type=password", { method: "POST",
        headers: { apikey: SUPABASE_ANON_KEY, "Content-Type": "application/json" }, body: JSON.stringify({ email, password: senha }) }).then(r => r.json());
      if (!j.access_token) throw new Error("E-mail ou senha incorretos.");
      sess.set({ access: j.access_token, refresh: j.refresh_token, exp: Date.now() + j.expires_in * 1000 });
    },
    logado() { return !!sess.get(); },
    sair() { sess.set(null); },
    async listar(de, ate) { return ((await sb(`/rest/v1/agendamentos?data=gte.${de}&data=lte.${ate}&order=data,hora`, { auth: true })) || []).map(norm); },
    async atualizar(id, patch) { await sb("/rest/v1/agendamentos?id=eq." + encodeURIComponent(id), { method: "PATCH", auth: true, body: patch }); },
    async criar(ag) { await sb("/rest/v1/agendamentos", { method: "POST", auth: true, body: ag, headers: { Prefer: "return=minimal" } }); },
    async bloqueios(de) {
      return ((await sb(`/rest/v1/bloqueios?data=gte.${de}&order=data,ini`, { auth: true })) || [])
        .map(b => Object.assign(b, { ini: b.ini ? b.ini.slice(0, 5) : "", fim: b.fim ? b.fim.slice(0, 5) : "" }));
    },
    async bloquear(b) { await sb("/rest/v1/bloqueios", { method: "POST", auth: true, body: { data: b.data, ini: b.ini || null, fim: b.fim || null, motivo: b.motivo || "" }, headers: { Prefer: "return=minimal" } }); },
    async desbloquear(id) { await sb("/rest/v1/bloqueios?id=eq." + encodeURIComponent(id), { method: "DELETE", auth: true }); },
    async setPin() { throw new Error("No modo online a senha é trocada no painel do Supabase (Authentication)."); },
    async exportar() {
      return { cfg: await this.getConfig(), ags: await this.listar("2000-01-01", "2100-01-01"), blq: await this.bloqueios("2000-01-01") };
    },
    async importar(d) { if (d.cfg) await this.saveConfig(d.cfg); }
  };

  window.Store = SUPABASE_URL && SUPABASE_ANON_KEY ? Supa : Local;
})();
