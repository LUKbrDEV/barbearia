// Lógica pura de datas e horários (sem DOM) — testável no Node.
(function (root) {
  const pad = n => String(n).padStart(2, "0");
  const toMin = hm => { if (!hm) return null; const [h, m] = hm.slice(0, 5).split(":").map(Number); return h * 60 + m; };
  const toHM = m => pad(Math.floor(m / 60)) + ":" + pad(m % 60);
  const ymd = d => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  const parseYMD = s => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
  const addDays = (s, n) => { const d = parseYMD(s); d.setDate(d.getDate() + n); return ymd(d); };
  const overlap = (a1, a2, b1, b2) => a1 < b2 && b1 < a2;

  // busy: [{data:"YYYY-MM-DD", ini:"HH:MM", fim:"HH:MM"}]  (ini vazio = dia todo bloqueado)
  function slotsDoDia(cfg, data, dur, busy, agora) {
    const h = cfg.horarios[parseYMD(data).getDay()];
    if (!h || !h.aberto) return { fechado: true, slots: [] };
    const abre = toMin(h.abre), fecha = toMin(h.fecha);
    const aIni = toMin(h.almocoIni), aFim = toMin(h.almocoFim);
    const doDia = busy.filter(b => b.data === data);
    if (doDia.some(b => !b.ini)) return { fechado: true, slots: [] };
    const ocup = doDia.map(b => [toMin(b.ini), toMin(b.fim)]);
    let minimo = -1;
    agora = agora || new Date();
    if (data === ymd(agora)) minimo = agora.getHours() * 60 + agora.getMinutes() + (cfg.antecedenciaMin || 0);
    else if (data < ymd(agora)) return { fechado: false, slots: [] };
    const passo = Math.max(5, cfg.intervalo || 30);
    const slots = [];
    for (let t = abre; t + dur <= fecha; t += passo) {
      let livre = t >= minimo;
      if (livre && aIni != null && aFim != null && overlap(t, t + dur, aIni, aFim)) livre = false;
      if (livre && ocup.some(([i, f]) => overlap(t, t + dur, i, f))) livre = false;
      slots.push({ hora: toHM(t), livre });
    }
    return { fechado: false, slots };
  }

  root.Agenda = { pad, toMin, toHM, ymd, parseYMD, addDays, overlap, slotsDoDia };
  if (typeof module !== "undefined") module.exports = root.Agenda;
})(typeof window !== "undefined" ? window : globalThis);
