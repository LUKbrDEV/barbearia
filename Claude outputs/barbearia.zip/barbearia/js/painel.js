// Painel do barbeiro: agenda, encaixes, bloqueios, serviços, horários, relatórios, clientes, ajustes.
{
  const A = window.Agenda, S = window.Store;
  const root = document.getElementById("v-painel");
  const { esc, money, toast, modal, fecharModal, fmtData, durTxt, wa, DIAS } = window.App;
  const cfg = () => window.App.cfg;
  const hoje = () => A.ymd(new Date());
  const ROT = { agendado: "Agendado", concluido: "Concluído", cancelado: "Cancelado", faltou: "Faltou" };
  let aba = "agenda", dia = hoje(), timer = null, conhecidos = null, periodo = "7";

  function render() {
    clearInterval(timer);
    if (!S.logado()) return login();
    root.innerHTML = `<div class="p-top"><h1>Painel</h1><div style="display:flex;gap:8px"><a class="btn btn-mini btn-sec" href="#inicio">Ver site</a><button class="btn btn-mini btn-sec" id="pSair">Sair</button></div></div>
      <div class="p-tabs" role="tablist">${[["agenda", "Agenda"], ["bloq", "Bloqueios"], ["serv", "Serviços"], ["hor", "Horários"], ["rel", "Relatórios"], ["cli", "Clientes"], ["aj", "Ajustes"]]
        .map(([k, t]) => `<button role="tab" data-aba="${k}" class="${aba === k ? "ativo" : ""}">${t}</button>`).join("")}</div>
      <div class="p-sec" id="pConteudo"></div>`;
    root.querySelector("#pSair").onclick = () => { S.sair(); location.hash = "inicio"; };
    root.querySelector(".p-tabs").onclick = e => { const b = e.target.closest("[data-aba]"); if (b) { aba = b.dataset.aba; render(); } };
    ({ agenda, bloq, serv, hor, rel, cli, aj })[aba]();
  }
  const box = () => root.querySelector("#pConteudo");

  // ---------- LOGIN ----------
  function login() {
    const online = S.modo === "supabase";
    root.innerHTML = `<form class="login" id="fLogin"><h1>Área do barbeiro</h1>
      <p>${online ? "Entre com o e-mail e senha cadastrados." : "Modo demonstração: os dados ficam só neste aparelho. PIN inicial: 1234."}</p>
      ${online ? `<label class="campo"><span class="sr">E-mail</span><input id="lEmail" type="email" autocomplete="username" placeholder="E-mail" required></label>` : ""}
      <label class="campo"><span class="sr">${online ? "Senha" : "PIN"}</span><input id="lSenha" type="password" ${online ? 'autocomplete="current-password"' : 'inputmode="numeric"'} placeholder="${online ? "Senha" : "PIN"}" required></label>
      <p class="erro" id="lErro"></p><button class="btn" style="width:100%">Entrar</button>
      <p style="text-align:center"><a href="#inicio">Voltar ao site</a></p></form>`;
    root.querySelector("#fLogin").onsubmit = async e => {
      e.preventDefault();
      try { await S.login(online ? root.querySelector("#lEmail").value.trim() : "", root.querySelector("#lSenha").value); conhecidos = null; render(); }
      catch (err) { root.querySelector("#lErro").textContent = err.message; }
    };
  }

  // ---------- AGENDA ----------
  async function agenda() {
    box().innerHTML = `<div class="dia-nav"><button class="btn btn-sec" id="dAnt" aria-label="Dia anterior">‹</button>
      <input type="date" id="dSel" value="${dia}"><button class="btn btn-sec" id="dProx" aria-label="Próximo dia">›</button></div>
      <div class="seg"><button class="btn btn-mini btn-sec" id="dHoje">Hoje</button><button class="btn btn-mini" id="dEnc">+ Encaixe</button></div>
      <div id="aKpis" class="kpis"></div><h2 id="aTit"></h2><div id="aLista"><p class="vazio">Carregando…</p></div>`;
    const ir = d => { dia = d; agenda(); };
    box().querySelector("#dAnt").onclick = () => ir(A.addDays(dia, -1));
    box().querySelector("#dProx").onclick = () => ir(A.addDays(dia, 1));
    box().querySelector("#dHoje").onclick = () => ir(hoje());
    box().querySelector("#dSel").onchange = e => e.target.value && ir(e.target.value);
    box().querySelector("#dEnc").onclick = encaixe;
    await listaDia();
    timer = setInterval(() => { if (!document.hidden && aba === "agenda" && location.hash === "#painel") listaDia(true); }, 30000);
  }
  async function listaDia(silencioso) {
    let ags, blq;
    try { [ags, blq] = await Promise.all([S.listar(dia, dia), S.bloqueios(dia)]); }
    catch (e) { if (!silencioso) box().querySelector("#aLista").innerHTML = `<p class="erro">${esc(e.message)}</p>`; return; }
    novosAvisos(ags);
    blq = blq.filter(b => b.data === dia);
    const ativos = ags.filter(a => a.status !== "cancelado");
    const fat = ags.filter(a => a.status === "concluido").reduce((s, a) => s + a.preco, 0);
    const prev = ags.filter(a => a.status === "agendado").reduce((s, a) => s + a.preco, 0);
    const k = box().querySelector("#aKpis"); if (!k) return;
    k.innerHTML = `<div class="kpi"><small>Atendimentos</small><b>${ativos.length}</b></div>
      <div class="kpi"><small>Recebido</small><b>${money(fat)}</b></div><div class="kpi"><small>A receber</small><b>${money(prev)}</b></div>`;
    box().querySelector("#aTit").textContent = fmtData(dia, true).replace(/^./, c => c.toUpperCase());
    const h = cfg().horarios[A.parseYMD(dia).getDay()];
    let itens = ags.map(a => ({ t: a.hora, tipo: "ag", a }))
      .concat(blq.map(b => ({ t: b.ini || "00:00", tipo: "blq", b })));
    if (h && h.almocoIni && h.aberto) itens.push({ t: h.almocoIni, tipo: "alm" });
    itens.sort((x, y) => x.t.localeCompare(y.t));
    const lista = box().querySelector("#aLista");
    if (!itens.length) { lista.innerHTML = `<p class="vazio">${h && h.aberto ? "Nenhum agendamento neste dia." : "Fechado neste dia."}</p>`; return; }
    lista.innerHTML = itens.map(i => {
      if (i.tipo === "alm") return `<div class="ag-item livre"><div class="h">${esc(h.almocoIni)}<small>até ${esc(h.almocoFim)}</small></div><div class="n">Pausa / almoço</div></div>`;
      if (i.tipo === "blq") return `<div class="ag-item livre"><div class="h">${i.b.ini ? esc(i.b.ini) : "Dia"}<small>${i.b.ini ? "até " + esc(i.b.fim) : "inteiro"}</small></div><div class="n">Bloqueado${i.b.motivo ? " · " + esc(i.b.motivo) : ""}</div></div>`;
      const a = i.a;
      return `<div class="ag-item st-${esc(a.status)}" data-id="${esc(a.id)}"><div class="h">${esc(a.hora)}<small>${esc(durTxt(a.dur))}</small></div>
        <div><b>${esc(a.nome)}</b> <span class="tag ${esc(a.status)}">${esc(ROT[a.status] || a.status)}</span><br>
        <span style="color:var(--mut)">${esc(a.servico_nome)} · ${money(a.preco)}${a.origem === "encaixe" ? " · encaixe" : ""}</span></div>
        <div class="acoes">${a.status === "agendado" ? `<button class="btn btn-mini btn-ok" data-s="concluido">Concluir</button><button class="btn btn-mini btn-sec" data-s="faltou">Faltou</button><button class="btn btn-mini btn-sec" data-s="cancelado">Cancelar</button>`
          : `<button class="btn btn-mini btn-sec" data-s="agendado">Desfazer</button>`}
          ${a.telefone ? `<a class="btn btn-mini btn-sec" target="_blank" rel="noopener" href="${esc(wa(a.telefone.length <= 11 ? "55" + a.telefone.replace(/\D/g, "") : a.telefone, `Olá ${a.nome}! Confirmando seu horário na ${cfg().nome}: ${fmtData(a.data)} às ${a.hora}.`))}">WhatsApp</a>` : ""}</div></div>`;
    }).join("");
    lista.onclick = async e => {
      const b = e.target.closest("[data-s]"); if (!b) return;
      try { await S.atualizar(b.closest("[data-id]").dataset.id, { status: b.dataset.s }); toast("Atualizado."); listaDia(); }
      catch (err) { toast(err.message); }
    };
  }
  function novosAvisos(ags) {
    const ids = new Set(ags.map(a => a.id));
    if (conhecidos && conhecidos.dia === dia) {
      const novos = ags.filter(a => !conhecidos.ids.has(a.id) && a.origem === "online");
      if (novos.length) {
        const n = novos[0], txt = `Novo agendamento: ${n.nome} às ${n.hora}`;
        toast(txt);
        try { if (Notification.permission === "granted") navigator.serviceWorker.ready.then(r => r.showNotification(cfg().nome, { body: txt, icon: "icons/icon-192.png" })); } catch {}
      }
    }
    conhecidos = { dia, ids };
  }
  function encaixe() {
    const b = modal(`<h2>Encaixe</h2><form id="fEnc" class="form-grid">
      <label style="grid-column:1/-1">Nome do cliente<input name="nome" required maxlength="60"></label>
      <label style="grid-column:1/-1">Serviço<select name="serv">${cfg().servicos.map(s => `<option value="${esc(s.id)}">${esc(s.nome)} · ${money(s.preco)}</option>`).join("")}</select></label>
      <label>Data<input type="date" name="data" value="${dia}" required></label>
      <label>Hora<input type="time" name="hora" value="${A.toHM(Math.ceil((new Date().getHours() * 60 + new Date().getMinutes()) / 15) * 15 % 1440)}" required></label>
      <label style="grid-column:1/-1">WhatsApp (opcional)<input name="tel" type="tel" inputmode="tel"></label>
      <p class="erro" id="encErro" style="grid-column:1/-1"></p>
      <button class="btn" style="grid-column:1/-1">Salvar encaixe</button><button type="button" class="btn btn-sec" data-fechar style="grid-column:1/-1">Cancelar</button></form>`);
    b.querySelector("#fEnc").onsubmit = async e => {
      e.preventDefault(); const f = e.target, s = cfg().servicos.find(x => x.id === f.serv.value);
      if (f.nome.value.trim().length < 2) { b.querySelector("#encErro").textContent = "Digite o nome."; return; }
      try {
        await S.criar({ data: f.data.value, hora: f.hora.value, dur: s.dur, servico_id: s.id, servico_nome: s.nome, preco: s.preco,
          nome: f.nome.value.trim(), telefone: f.tel.value.trim(), status: "agendado", origem: "encaixe" });
        fecharModal(); toast("Encaixe salvo."); dia = f.data.value; agenda();
      } catch (err) { b.querySelector("#encErro").textContent = err.message; }
    };
  }

  // ---------- BLOQUEIOS ----------
  async function bloq() {
    box().innerHTML = `<h2>Bloquear horário ou folga</h2><form id="fBlq" class="form-grid">
      <label>Data<input type="date" name="data" value="${hoje()}" min="${hoje()}" required></label>
      <label class="switch" style="align-self:end;min-height:48px"><input type="checkbox" name="todo" checked> Dia inteiro</label>
      <label class="hr">Das<input type="time" name="ini" value="12:00" disabled></label><label class="hr">Até<input type="time" name="fim" value="14:00" disabled></label>
      <label style="grid-column:1/-1">Motivo (opcional)<input name="motivo" maxlength="60" placeholder="Feriado, curso, consulta…"></label>
      <button class="btn" style="grid-column:1/-1">Bloquear</button></form>
      <p class="aviso" style="margin-top:14px">Horários bloqueados somem da agenda do cliente. Agendamentos já marcados continuam: avise o cliente pelo WhatsApp.</p>
      <h2>Próximos bloqueios</h2><div id="bLista"><p class="vazio">Carregando…</p></div>`;
    const f = box().querySelector("#fBlq");
    f.todo.onchange = () => { f.ini.disabled = f.fim.disabled = f.todo.checked; };
    f.onsubmit = async e => {
      e.preventDefault();
      if (!f.todo.checked && f.ini.value >= f.fim.value) { toast("O horário final deve ser depois do inicial."); return; }
      try { await S.bloquear({ data: f.data.value, ini: f.todo.checked ? "" : f.ini.value, fim: f.todo.checked ? "" : f.fim.value, motivo: f.motivo.value.trim() }); toast("Bloqueado."); bloq(); }
      catch (err) { toast(err.message); }
    };
    try {
      const l = await S.bloqueios(hoje());
      const el = box().querySelector("#bLista");
      el.innerHTML = l.length ? l.map(b => `<div class="cli"><div><b>${esc(fmtData(b.data, true))}</b><small>${b.ini ? esc(b.ini) + " – " + esc(b.fim) : "Dia inteiro"}${b.motivo ? " · " + esc(b.motivo) : ""}</small></div><button class="btn btn-mini btn-sec" data-id="${esc(b.id)}">Remover</button></div>`).join("") : `<p class="vazio">Nenhum bloqueio.</p>`;
      el.onclick = async e => { const b = e.target.closest("[data-id]"); if (!b) return; await S.desbloquear(b.dataset.id); toast("Removido."); bloq(); };
    } catch (err) { toast(err.message); }
  }

  // ---------- SERVIÇOS ----------
  function serv() {
    let lista = JSON.parse(JSON.stringify(cfg().servicos));
    const desenhar = () => {
      box().innerHTML = `<h2>Serviços e preços</h2><div id="sLista">${lista.map((s, i) => `<div class="serv-ed form-grid" data-i="${i}">
        <label style="grid-column:1/-1">Nome<input data-k="nome" value="${esc(s.nome)}" maxlength="40"></label>
        <label>Preço (R$)<input data-k="preco" type="number" inputmode="decimal" min="0" step="0.5" value="${esc(s.preco)}"></label>
        <label>Duração (min)<input data-k="dur" type="number" inputmode="numeric" min="5" step="5" value="${esc(s.dur)}"></label>
        <label style="grid-column:1/-1">Descrição<input data-k="desc" value="${esc(s.desc || "")}" maxlength="90"></label>
        <div style="grid-column:1/-1;display:flex;gap:6px;flex-wrap:wrap"><button class="btn btn-mini btn-sec" data-m="-1" ${i ? "" : "disabled"}>Subir</button><button class="btn btn-mini btn-sec" data-m="1" ${i < lista.length - 1 ? "" : "disabled"}>Descer</button><button class="btn btn-mini btn-sec" data-del>Excluir</button></div></div>`).join("")}</div>
        <div class="seg" style="margin-top:16px"><button class="btn btn-sec" id="sAdd">+ Novo serviço</button><button class="btn" id="sSalvar">Salvar serviços</button></div>`;
      box().querySelector("#sLista").oninput = e => { const k = e.target.dataset.k; if (!k) return; const i = +e.target.closest("[data-i]").dataset.i; lista[i][k] = k === "preco" || k === "dur" ? Number(e.target.value) : e.target.value; };
      box().querySelector("#sLista").onclick = e => {
        const it = e.target.closest("[data-i]"); if (!it) return; const i = +it.dataset.i;
        if (e.target.dataset.m) { const j = i + Number(e.target.dataset.m); [lista[i], lista[j]] = [lista[j], lista[i]]; desenhar(); }
        if (e.target.hasAttribute("data-del")) { lista.splice(i, 1); desenhar(); }
      };
      box().querySelector("#sAdd").onclick = () => { lista.push({ id: "s" + Date.now().toString(36), nome: "Novo serviço", preco: 0, dur: 30, desc: "" }); desenhar(); };
      box().querySelector("#sSalvar").onclick = async () => {
        if (!lista.length) return toast("Mantenha ao menos um serviço.");
        if (lista.some(s => !s.nome.trim() || !(s.dur >= 5))) return toast("Confira nome e duração (mín. 5 min).");
        await salvarCfg({ servicos: lista });
      };
    };
    desenhar();
  }

  async function salvarCfg(patch) {
    try { const n = Object.assign({}, cfg(), patch); await S.saveConfig(n); await window.App.recarregar(); toast("Salvo!"); }
    catch (err) { toast(err.message); }
  }

  // ---------- HORÁRIOS ----------
  function hor() {
    const c = cfg(), H = JSON.parse(JSON.stringify(c.horarios));
    box().innerHTML = `<h2>Funcionamento</h2><div id="hDias">${[1, 2, 3, 4, 5, 6, 0].map(d => { const h = H[d]; return `<div class="linha-dia" data-d="${d}">
      <label class="switch"><input type="checkbox" data-k="aberto" ${h.aberto ? "checked" : ""}>${DIAS[d].slice(0, 3)}</label>
      <input type="time" data-k="abre" value="${esc(h.abre)}" aria-label="Abre"><input type="time" data-k="fecha" value="${esc(h.fecha)}" aria-label="Fecha">
      <div class="alm"><small>Pausa (deixe vazio se não tiver)</small><input type="time" data-k="almocoIni" value="${esc(h.almocoIni)}" aria-label="Início da pausa"><input type="time" data-k="almocoFim" value="${esc(h.almocoFim)}" aria-label="Fim da pausa"></div></div>`; }).join("")}</div>
      <h2 style="margin-top:24px">Regras do agendamento</h2><div class="form-grid">
      <label>Intervalo entre horários<select id="hInt">${[10, 15, 20, 30, 40, 45, 60].map(v => `<option ${c.intervalo == v ? "selected" : ""} value="${v}">${v} min</option>`).join("")}</select></label>
      <label>Antecedência mínima<select id="hAnt">${[0, 15, 30, 60, 120, 180, 1440].map(v => `<option ${c.antecedenciaMin == v ? "selected" : ""} value="${v}">${v >= 1440 ? "1 dia" : v >= 60 ? v / 60 + " h" : v + " min"}</option>`).join("")}</select></label>
      <label>Agenda aberta por<select id="hDias2">${[7, 14, 21, 30, 45, 60].map(v => `<option ${c.diasAgenda == v ? "selected" : ""} value="${v}">${v} dias</option>`).join("")}</select></label></div>
      <button class="btn" id="hSalvar" style="margin-top:18px;width:100%">Salvar horários</button>`;
    box().querySelector("#hDias").oninput = e => { const k = e.target.dataset.k; if (!k) return; H[e.target.closest("[data-d]").dataset.d][k] = e.target.type === "checkbox" ? e.target.checked : e.target.value; };
    box().querySelector("#hSalvar").onclick = () => {
      for (const d in H) { const h = H[d]; if (h.aberto && (!h.abre || !h.fecha || h.abre >= h.fecha)) return toast(`Confira o horário de ${DIAS[d]}.`);
        if ((h.almocoIni && !h.almocoFim) || (!h.almocoIni && h.almocoFim) || (h.almocoIni && h.almocoIni >= h.almocoFim)) return toast(`Confira a pausa de ${DIAS[d]}.`); }
      salvarCfg({ horarios: H, intervalo: +box().querySelector("#hInt").value, antecedenciaMin: +box().querySelector("#hAnt").value, diasAgenda: +box().querySelector("#hDias2").value });
    };
  }

  // ---------- RELATÓRIOS ----------
  async function rel() {
    const P = { "0": "Hoje", "7": "7 dias", "mes": "Este mês", "30": "30 dias", "90": "90 dias" };
    box().innerHTML = `<div class="seg">${Object.entries(P).map(([k, t]) => `<button class="btn btn-mini ${periodo === k ? "" : "btn-sec"}" data-p="${k}">${t}</button>`).join("")}</div><div id="rOut"><p class="vazio">Carregando…</p></div>`;
    box().querySelector(".seg").onclick = e => { const b = e.target.closest("[data-p]"); if (b) { periodo = b.dataset.p; rel(); } };
    const fim = hoje(), ini = periodo === "mes" ? fim.slice(0, 8) + "01" : A.addDays(fim, -(+periodo || 0));
    let ags; try { ags = await S.listar(ini, A.addDays(fim, 60)); } catch (err) { box().querySelector("#rOut").innerHTML = `<p class="erro">${esc(err.message)}</p>`; return; }
    const noP = ags.filter(a => a.data <= fim || a.status !== "agendado"), futuros = ags.filter(a => a.data > fim || (a.data === fim && a.status === "agendado"));
    const conc = noP.filter(a => a.status === "concluido"), fat = conc.reduce((s, a) => s + a.preco, 0);
    const faltas = noP.filter(a => a.status === "faltou").length, canc = noP.filter(a => a.status === "cancelado").length;
    const prev = futuros.filter(a => a.status === "agendado").reduce((s, a) => s + a.preco, 0);
    const porServ = {}; conc.forEach(a => { porServ[a.servico_nome] = porServ[a.servico_nome] || { n: 0, v: 0 }; porServ[a.servico_nome].n++; porServ[a.servico_nome].v += a.preco; });
    const servs = Object.entries(porServ).sort((a, b) => b[1].v - a[1].v), maxS = Math.max(1, ...servs.map(s => s[1].v));
    const porDia = [0, 0, 0, 0, 0, 0, 0]; conc.forEach(a => porDia[A.parseYMD(a.data).getDay()]++); const maxD = Math.max(1, ...porDia);
    const porHora = {}; conc.forEach(a => { const h = a.hora.slice(0, 2); porHora[h] = (porHora[h] || 0) + 1; });
    const pico = Object.entries(porHora).sort((a, b) => b[1] - a[1])[0];
    box().querySelector("#rOut").innerHTML = `<div class="kpis">
      <div class="kpi"><small>Faturamento</small><b>${money(fat)}</b></div><div class="kpi"><small>Atendimentos</small><b>${conc.length}</b></div>
      <div class="kpi"><small>Ticket médio</small><b>${money(conc.length ? fat / conc.length : 0)}</b></div><div class="kpi"><small>Faltas / cancel.</small><b>${faltas} / ${canc}</b></div>
      <div class="kpi"><small>Agendado a receber</small><b>${money(prev)}</b></div><div class="kpi"><small>Horário de pico</small><b>${pico ? pico[0] + "h" : "—"}</b></div></div>
      <h2>Receita por serviço</h2>${servs.length ? servs.map(([n, s]) => `<div class="barra"><span>${esc(n)} <small style="color:var(--mut)">(${s.n})</small></span><span>${money(s.v)}</span><div class="trilho"><i style="width:${(s.v / maxS * 100).toFixed(1)}%"></i></div></div>`).join("") : `<p class="vazio">Nenhum atendimento concluído no período. Marque como “Concluir” na agenda.</p>`}
      <h2 style="margin-top:24px">Movimento por dia da semana</h2>${[1, 2, 3, 4, 5, 6, 0].map(d => `<div class="barra"><span>${DIAS[d]}</span><span>${porDia[d]}</span><div class="trilho"><i style="width:${(porDia[d] / maxD * 100).toFixed(1)}%;background:var(--azul)"></i></div></div>`).join("")}`;
  }

  // ---------- CLIENTES ----------
  async function cli() {
    box().innerHTML = `<input class="busca" id="cBusca" type="search" placeholder="Buscar cliente"><div id="cLista"><p class="vazio">Carregando…</p></div>`;
    let ags; try { ags = await S.listar(A.addDays(hoje(), -365), A.addDays(hoje(), 90)); } catch (err) { toast(err.message); return; }
    const m = {};
    ags.forEach(a => {
      const k = a.nome.trim().toLowerCase() + "|" + (a.telefone || "").replace(/\D/g, "");
      const c = m[k] = m[k] || { nome: a.nome.trim(), tel: a.telefone, n: 0, total: 0, ult: "", faltas: 0, prox: "" };
      if (a.status === "concluido") { c.n++; c.total += a.preco; if (a.data > c.ult) c.ult = a.data; }
      if (a.status === "faltou") c.faltas++;
      if (a.status === "agendado" && a.data >= hoje() && (!c.prox || a.data < c.prox)) c.prox = a.data;
    });
    const todos = Object.values(m).sort((a, b) => b.n - a.n || a.nome.localeCompare(b.nome));
    const desenhar = q => {
      const l = todos.filter(c => !q || c.nome.toLowerCase().includes(q) || (c.tel || "").includes(q));
      box().querySelector("#cLista").innerHTML = l.length ? `<p style="color:var(--mut);margin-top:0">${l.length} cliente(s) nos últimos 12 meses</p>` + l.map(c => `<div class="cli"><div><b>${esc(c.nome)}</b>
        <small>${c.n} visita(s) · ${money(c.total)}${c.ult ? " · última " + esc(fmtData(c.ult)) : ""}${c.prox ? " · próximo " + esc(fmtData(c.prox)) : ""}${c.faltas ? " · " + c.faltas + " falta(s)" : ""}</small></div>
        ${c.tel ? `<a class="btn btn-mini btn-ok" target="_blank" rel="noopener" href="${esc(wa(c.tel.replace(/\D/g, "").length <= 11 ? "55" + c.tel.replace(/\D/g, "") : c.tel, `Olá ${c.nome}! Tudo certo? Bora agendar o próximo corte na ${cfg().nome}?`))}">WhatsApp</a>` : ""}</div>`).join("")
        : `<p class="vazio">Nenhum cliente encontrado.</p>`;
    };
    box().querySelector("#cBusca").oninput = e => desenhar(e.target.value.trim().toLowerCase());
    desenhar("");
  }

  // ---------- AJUSTES ----------
  function aj() {
    const c = cfg(), online = S.modo === "supabase";
    box().innerHTML = `${online ? "" : `<p class="aviso"><b>Modo demonstração:</b> os agendamentos ficam salvos só neste aparelho. Para clientes agendarem do celular deles, conecte o Supabase (veja o LEIAME).</p>`}
      <h2>Dados da barbearia</h2><form id="fAj" class="form-grid">
      <label style="grid-column:1/-1">Nome<input name="nome" value="${esc(c.nome)}" maxlength="40" required></label>
      <label style="grid-column:1/-1">Frase de apresentação<input name="slogan" value="${esc(c.slogan)}" maxlength="80"></label>
      <label>WhatsApp (com DDI e DDD)<input name="whatsapp" inputmode="tel" value="${esc(c.whatsapp)}" placeholder="5538999990000"></label>
      <label>Instagram<input name="instagram" value="${esc(c.instagram)}" placeholder="seuperfil"></label>
      <label style="grid-column:1/-1">Endereço<input name="endereco" value="${esc(c.endereco)}"></label>
      <label style="grid-column:1/-1">Link do Google Maps (opcional)<input name="mapsUrl" type="url" value="${esc(c.mapsUrl)}"></label>
      <label class="switch" style="grid-column:1/-1"><input type="checkbox" name="pedirTelefone" ${c.pedirTelefone ? "checked" : ""}> Pedir WhatsApp do cliente no agendamento (opcional para ele)</label>
      <button class="btn" style="grid-column:1/-1">Salvar dados</button></form>
      <h2 style="margin-top:28px">Avisos de novos agendamentos</h2>
      <p style="color:var(--mut)">Com o painel aberto, você recebe um aviso a cada novo agendamento.</p>
      <button class="btn btn-sec" id="ajNotif">Ativar notificações</button>
      ${online ? "" : `<h2 style="margin-top:28px">Trocar PIN</h2><form id="fPin" class="form-grid"><label>Novo PIN<input name="pin" type="password" inputmode="numeric" minlength="4" required></label><button class="btn btn-sec" style="align-self:end">Trocar PIN</button></form>`}
      <h2 style="margin-top:28px">Backup</h2>
      <div class="seg"><button class="btn btn-sec" id="ajExp">Baixar backup</button><button class="btn btn-sec" id="ajCopy">Copiar backup</button>
      ${online ? "" : `<label class="btn btn-sec">Restaurar backup<input type="file" id="ajImp" accept=".json,application/json" hidden></label>`}</div>`;
    box().querySelector("#fAj").onsubmit = e => {
      e.preventDefault(); const f = e.target;
      salvarCfg({ nome: f.nome.value.trim() || c.nome, slogan: f.slogan.value.trim(), whatsapp: f.whatsapp.value.replace(/\D/g, ""), instagram: f.instagram.value.trim().replace("@", ""),
        endereco: f.endereco.value.trim(), mapsUrl: f.mapsUrl.value.trim(), pedirTelefone: f.pedirTelefone.checked });
    };
    box().querySelector("#ajNotif").onclick = async () => {
      try { const p = await Notification.requestPermission(); toast(p === "granted" ? "Notificações ativadas." : "Permissão negada no navegador."); }
      catch { toast("Este navegador não suporta notificações."); }
    };
    const fp = box().querySelector("#fPin");
    if (fp) fp.onsubmit = async e => { e.preventDefault(); try { await S.setPin(fp.pin.value); await window.App.recarregar(); toast("PIN trocado."); fp.reset(); } catch (err) { toast(err.message); } };
    box().querySelector("#ajExp").onclick = async () => {
      const d = await S.exportar(), a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([JSON.stringify(d, null, 2)], { type: "application/json" })); a.download = "backup-barbearia-" + hoje() + ".json";
      document.body.appendChild(a); a.click(); a.remove();
    };
    box().querySelector("#ajCopy").onclick = async () => {
      try { await navigator.clipboard.writeText(JSON.stringify(await S.exportar())); toast("Backup copiado."); } catch { toast("Não foi possível copiar."); }
    };
    const imp = box().querySelector("#ajImp");
    if (imp) imp.onchange = async () => {
      try { const d = JSON.parse(await imp.files[0].text()); await S.importar(d); await window.App.recarregar(); toast("Backup restaurado."); render(); }
      catch { toast("Arquivo inválido."); }
    };
  }

  window.Painel = { render };
}
