# App da Barbearia (PWA)

Site instalável (Android, iPhone e desktop) em HTML, CSS e JavaScript puro — sem build, sem dependências.

## Funcionalidades

**Cliente**
- Agendamento em 4 toques: serviço → dia → horário → nome. Só aparecem horários realmente livres (considera duração do serviço, pausa de almoço, bloqueios, antecedência mínima e horários já ocupados).
- Confirmação com botão "Avisar no WhatsApp" e "Adicionar ao calendário" (.ics com lembrete 1h antes).
- "Meus horários": lista os agendamentos feitos no aparelho, com status atualizado e cancelamento.
- Início com status aberto/fechado, próximo horário livre, serviços e preços, horário de funcionamento, WhatsApp, Instagram e "Como chegar".
- Nome (e telefone) lembrados para o próximo agendamento.

**Barbeiro** (`#painel`, link "Área do barbeiro" no rodapé)
- Agenda do dia: concluir, faltou, cancelar, desfazer, WhatsApp do cliente; totais recebido / a receber.
- Encaixe (cliente que chegou sem agendar).
- Aviso de novo agendamento (atualiza a cada 30 s; notificação do sistema se permitida).
- Bloqueios: folga de dia inteiro ou faixa de horário.
- Serviços: criar, editar preço/duração/descrição, reordenar, excluir.
- Horários por dia da semana, pausa, intervalo entre horários, antecedência mínima, dias de agenda aberta.
- Relatórios: faturamento, atendimentos, ticket médio, faltas, horário de pico, receita por serviço, movimento por dia.
- Clientes: histórico de visitas, total gasto, faltas, busca e WhatsApp para chamar de volta.
- Ajustes: nome, slogan, WhatsApp, endereço, Instagram, pedir telefone, PIN, backup.

## Dois modos

1. **Demonstração (padrão):** `js/config.js` com `SUPABASE_URL` vazio. Tudo fica salvo no navegador do aparelho. PIN do painel: `1234`. Bom para testar, **não** serve para uso real (o cliente agenda no celular dele e o barbeiro não veria).
2. **Online (produção) — Supabase grátis:**
   1. Crie um projeto em supabase.com.
   2. SQL Editor → cole `supabase/schema.sql` → Run.
   3. Authentication → Users → Add user (e-mail e senha do barbeiro).
   4. Authentication → Providers → Email → desative **Allow new users to sign up**.
   5. Project Settings → API → copie a URL e a chave `anon public` para `js/config.js`.
   6. Entre no painel e salve os Ajustes, Serviços e Horários uma vez (grava a configuração no banco).

   Segurança: o cliente nunca lê a tabela. Ele só chama funções que retornam horários ocupados (sem nomes), criam o agendamento (checando conflito no servidor, com trava contra agendamento duplo) e cancelam pelo token do próprio agendamento.

## Publicar

Precisa de **HTTPS** para instalar (Vercel, Netlify, GitHub Pages, Cloudflare Pages). Basta enviar a pasta inteira. Em `localhost` também funciona para teste.

Ao atualizar arquivos, troque `VERSAO` no `sw.js` (ex.: `barbearia-v2`) para os celulares pegarem a nova versão.

## Estrutura
```
index.html            telas do cliente e container do painel
css/style.css         visual (claro/escuro automático, mobile first)
js/config.js          Supabase + configuração inicial
js/agenda.js          cálculo de horários livres
js/store.js           dados: modo local ou Supabase
js/app.js             cliente + PWA
js/painel.js          painel do barbeiro
manifest.webmanifest  instalação (ícones, atalhos "Agendar" e "Painel")
sw.js                 offline e cache
supabase/schema.sql   banco, segurança e funções
icons/                ícones do app
```
