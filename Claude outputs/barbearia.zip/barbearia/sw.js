// Service worker: funciona offline e deixa o app instalável.
const VERSAO = "barbearia-v1";
const ARQUIVOS = ["./", "index.html", "css/style.css", "js/config.js", "js/agenda.js", "js/store.js", "js/app.js", "js/painel.js",
  "manifest.webmanifest", "icons/icon-192.png", "icons/icon-512.png", "icons/maskable-512.png", "icons/apple-touch-icon.png"];

self.addEventListener("install", e => { e.waitUntil(caches.open(VERSAO).then(c => c.addAll(ARQUIVOS)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSAO).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== "GET") return;
  // Dados (Supabase) sempre da rede
  if (url.hostname.endsWith("supabase.co") || url.pathname.includes("/rest/") || url.pathname.includes("/auth/")) return;
  // Fontes: cache primeiro
  if (url.hostname.includes("fonts.g")) {
    e.respondWith(caches.open(VERSAO).then(c => c.match(req).then(r => r || fetch(req).then(n => { c.put(req, n.clone()); return n; }))));
    return;
  }
  if (url.origin !== location.origin) return;
  // App: rede primeiro (pega atualizações), cache se offline
  e.respondWith(fetch(req).then(n => { const cp = n.clone(); caches.open(VERSAO).then(c => c.put(req, cp)); return n; })
    .catch(() => caches.match(req, { ignoreSearch: true }).then(r => r || caches.match("index.html"))));
});
self.addEventListener("notificationclick", e => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: "window" }).then(cs => cs.length ? cs[0].focus() : self.clients.openWindow("./index.html#painel")));
});
