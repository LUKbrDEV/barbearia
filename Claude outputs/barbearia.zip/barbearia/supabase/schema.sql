-- ============================================================
-- Barbearia — esquema do Supabase
-- Cole tudo no SQL Editor do Supabase e clique em "Run".
-- Depois: Authentication > Users > "Add user" (e-mail e senha do barbeiro)
-- e Authentication > Providers > Email: DESATIVE "Allow new users to sign up".
-- ============================================================

create extension if not exists pgcrypto;

create table if not exists config (
  id int primary key default 1 check (id = 1),
  data jsonb not null default '{}'::jsonb
);
insert into config (id, data) values (1, '{}'::jsonb) on conflict do nothing;

create table if not exists agendamentos (
  id uuid primary key default gen_random_uuid(),
  data date not null,
  hora time not null,
  dur int not null check (dur between 5 and 480),
  servico_id text,
  servico_nome text not null,
  preco numeric(10,2) not null default 0,
  nome text not null check (char_length(nome) between 2 and 80),
  telefone text default '',
  status text not null default 'agendado' check (status in ('agendado','concluido','faltou','cancelado')),
  origem text not null default 'online',
  token text not null default gen_random_uuid()::text,
  criado_em timestamptz not null default now()
);
create index if not exists agendamentos_data_idx on agendamentos (data, hora);

create table if not exists bloqueios (
  id uuid primary key default gen_random_uuid(),
  data date not null,
  ini time,          -- null = dia inteiro
  fim time,
  motivo text default ''
);

-- ---------- Segurança: só o barbeiro (logado) acessa as tabelas ----------
alter table config enable row level security;
alter table agendamentos enable row level security;
alter table bloqueios enable row level security;

drop policy if exists config_ler on config;
create policy config_ler on config for select using (true);
drop policy if exists config_editar on config;
create policy config_editar on config for update to authenticated using (true) with check (true);

drop policy if exists ag_admin on agendamentos;
create policy ag_admin on agendamentos for all to authenticated using (true) with check (true);
drop policy if exists blq_admin on bloqueios;
create policy blq_admin on bloqueios for all to authenticated using (true) with check (true);

-- ---------- Funções públicas (o cliente nunca lê nomes de outros clientes) ----------
create or replace function horarios_ocupados(p_de date, p_ate date)
returns table (data date, ini time, fim time)
language sql security definer set search_path = public as $$
  select a.data, a.hora, a.hora + make_interval(mins => a.dur)
    from agendamentos a
   where a.data between p_de and p_ate and a.status in ('agendado','concluido')
  union all
  select b.data, b.ini, b.fim from bloqueios b where b.data between p_de and p_ate;
$$;

create or replace function agendar(p_servico text, p_nome text, p_tel text, p_data date, p_hora time)
returns json language plpgsql security definer set search_path = public as $$
declare
  s jsonb; v_dur int; v_fim time; r agendamentos;
begin
  select e into s from config c, jsonb_array_elements(c.data->'servicos') e
   where c.id = 1 and e->>'id' = p_servico limit 1;
  if s is null then raise exception 'servico invalido'; end if;
  if p_data < (now() at time zone 'America/Sao_Paulo')::date then raise exception 'data no passado'; end if;
  v_dur := (s->>'dur')::int;
  v_fim := p_hora + make_interval(mins => v_dur);

  perform pg_advisory_xact_lock(hashtext(p_data::text));
  if exists (select 1 from agendamentos a
              where a.data = p_data and a.status in ('agendado','concluido')
                and a.hora < v_fim and p_hora < a.hora + make_interval(mins => a.dur))
     or exists (select 1 from bloqueios b
              where b.data = p_data and (b.ini is null or (b.ini < v_fim and p_hora < b.fim))) then
    raise exception 'ocupado';
  end if;

  insert into agendamentos (data, hora, dur, servico_id, servico_nome, preco, nome, telefone)
  values (p_data, p_hora, v_dur, p_servico, s->>'nome', coalesce((s->>'preco')::numeric, 0),
          left(trim(p_nome), 80), left(coalesce(p_tel, ''), 20))
  returning * into r;
  return json_build_object('id', r.id, 'token', r.token);
end $$;

create or replace function cancelar_agendamento(p_id uuid, p_token text)
returns void language plpgsql security definer set search_path = public as $$
begin
  update agendamentos set status = 'cancelado'
   where id = p_id and token = p_token and status = 'agendado';
  if not found then raise exception 'nao foi possivel cancelar'; end if;
end $$;

create or replace function status_agendamentos(p_ids uuid[])
returns table (id uuid, status text)
language sql security definer set search_path = public as $$
  select a.id, a.status from agendamentos a where a.id = any(p_ids);
$$;

revoke all on function horarios_ocupados(date, date) from public;
revoke all on function agendar(text, text, text, date, time) from public;
revoke all on function cancelar_agendamento(uuid, text) from public;
revoke all on function status_agendamentos(uuid[]) from public;
grant execute on function horarios_ocupados(date, date) to anon, authenticated;
grant execute on function agendar(text, text, text, date, time) to anon, authenticated;
grant execute on function cancelar_agendamento(uuid, text) to anon, authenticated;
grant execute on function status_agendamentos(uuid[]) to anon, authenticated;
